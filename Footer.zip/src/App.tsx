import React from "react";
import Frame6 from "./components/Frame6";
import "./App.css";

function App() {
  return <Frame6 />;
}

export default App;
